import { Col, Container, Row } from "react-bootstrap";
import { useGlobal } from "../context/Global";
import Paper from "../components/Paper";

function Home() {
    const { products } = useGlobal();

    return (
        <>
            <Container>
                <Row className="g-5">
                    {products.map((product, index) => {
                        return (
                            <Col md={6} lg={4} key={index}>
                                <Paper id={product.id} title={product.title} picture_url={product.picture_url} unit_price={product.unit_price} />
                            </Col>
                        )
                    })}
                </Row>
            </Container>
        </>
    );
}

export default Home;
