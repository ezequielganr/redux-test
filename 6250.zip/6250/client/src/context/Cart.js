import React, { useContext, useState } from "react";

const context = React.createContext();

export const useCart = () => useContext(context);

function Cart({ children }) {
    const [cart, setCart] = useState([]);
    const [total, setTotal] = useState(0);

    const increment = (product) => {
        let index = cart.findIndex(x => x.id === product.id);

        if (index >= 0) {
            let result = [...cart];
            result[index].quantity += 1;
            setCart(result);
            setTotal(total + product.unit_price);

        } else {
            let result = Object.assign({ quantity: 1 }, product);
            setCart([...cart, result]);
            setTotal(total + product.unit_price);
        }
    }

    const decrement = (index) => {
        let result = [...cart];

        result[index].quantity -= 1;

        setTotal(total - result[index].unit_price);

        if (result[index].quantity === 0) {
            result.splice(index, 1);
        }

        setCart(result);
    }

    return (
        <context.Provider value={{ cart, total, increment, decrement }}>
            {children}
        </context.Provider>
    );
}

export default Cart;
