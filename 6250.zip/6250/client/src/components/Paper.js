import { Button, Card } from "react-bootstrap";
import { useCart } from "../context/Cart";

function Paper(props) {
    const { increment } = useCart();

    return (
        <>
            <Card className="shadow-sm">
                <Card.Img src={props.picture_url} alt={props.title} />
                <Card.Body>
                    <div className="text-center">
                        <Card.Title className="fw-bold">${props.unit_price.toFixed(2)}</Card.Title>
                        <Card.Text>{props.title}</Card.Text>

                        <Button variant="dark" onClick={() => increment(props)}>Agregar al carrito</Button>
                    </div>
                </Card.Body>
            </Card>
        </>
    );
}

export default Paper;
