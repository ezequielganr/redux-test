import { ListGroupItem, ButtonGroup, Button } from "react-bootstrap";
import { useCart } from "../context/Cart";

function Stack(props) {
    const { increment, decrement } = useCart();

    return (
        <ListGroupItem className="d-flex">
            <img src={props.product.picture_url} alt={props.product.title} className="img-fluid d-none d-lg-inline" width={60}></img>
            <p className="my-auto">{props.product.title}</p>

            <div className="ms-auto my-auto">
                <span>${props.product.unit_price.toFixed(2)}</span>
            </div>

            <div className="ms-auto my-auto">
                <ButtonGroup>
                    <Button variant="light" onClick={() => increment(props.product)}>

                        <img src="/icons/plus.svg" alt="" width={25}></img>
                    </Button>

                    <Button variant="light">{props.product.quantity}</Button>

                    <Button variant="light" onClick={() => decrement(props.index)}>

                        <img src="/icons/minus.svg" alt="" width={25}></img>
                    </Button>
                </ButtonGroup>
            </div>
        </ListGroupItem>
    );
}

export default Stack;
