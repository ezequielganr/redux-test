function __init__(id) {
    let script = document.createElement("script");
    script.type = "text/javascript";
    script.onload = () => {
        const mercadopago = new window.MercadoPago("TEST-29024c61-5d0a-4d9c-b801-608f968a2fae", {
            locale: "es-AR"
        });
        mercadopago.checkout({
            preference: {
                id
            },
            autoOpen: true
        });
    }
    script.src = "https://sdk.mercadopago.com/js/v2";
    document.getElementsByTagName("head")[0].appendChild(script);
}

export default __init__;
