import { Navbar, Container } from "react-bootstrap";
import { Link, Outlet } from "react-router-dom";
import { useCart } from "../context/Cart";

function Default() {
    const { total } = useCart();

    return (
        <>
            <Navbar sticky="top" bg="dark" expand="lg">
                <Container>
                    <Link to="/">
                        <img src="/logo192.png" width={35} className="img-fluid"></img>
                        <span className="text-white ms-3">Tienda e-commerce</span>
                    </Link>

                    <Link className="btn btn-dark" to="/cart">
                        <img src="/icons/cart.svg" alt="" width={30}></img>
                        <span className="ms-2 fw-bold d-none d-lg-inline">${total.toFixed(2)}</span>
                    </Link>
                </Container>
            </Navbar>
            <br></br>

            <Outlet />
        </>
    );
}

export default Default;
