import React, { useContext, useEffect, useState } from "react";
import axios from "axios";

const context = React.createContext();

export const useGlobal = () => useContext(context);

function Global({ children }) {
    const [products, setProducts] = useState([]);
    const url = "http://localhost:3001";

    const all = async () => {
        let response = await axios.get("/test.json");
        setProducts(response.data);
    }

    useEffect(() => {
        all();
    }, []);

    return (
        <context.Provider value={{ products, url }}>
            {children}
        </context.Provider>
    );
}

export default Global;
