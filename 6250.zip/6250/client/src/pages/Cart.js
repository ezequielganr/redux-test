import { Button, Card, Col, Container, ListGroup, Row, Spinner } from "react-bootstrap";
import { useCart } from "../context/Cart";
import Stack from "../components/Stack";
import axios from "axios";
import mercadopago from "../mercadopago";
import { useState } from "react";
import { useGlobal } from "../context/Global";

function Cart() {
    const { cart, total } = useCart();
    const { url } = useGlobal();
    const [show, setShow] = useState(false);

    const handlePay = async () => {
        setShow(true);
        let response = await axios.post(url + "/create_preference", { payload: cart });
        mercadopago(response.data.id);
        setShow(false);
    }

    return (
        <>
            <Container>
                <Row className="g-5">
                    <Col>
                        {cart.length === 0 ? <p className="text-center">El carrito de compras está vacío</p> : null}
                        <ListGroup>
                            {cart.map((product, index) => {
                                return (
                                    <Stack key={index} index={index} product={product} />
                                )
                            })}
                        </ListGroup>
                    </Col>
                    <Col lg={4}>
                        <Card>
                            <Card.Body>
                                <Card.Title>Total: ${total.toFixed(2)}</Card.Title>
                                <br></br>

                                <Button variant="dark" className="w-100" disabled={cart.length === 0 ? true : false} onClick={handlePay}>
                                    {show ? <Spinner animation="border"></Spinner> : "Pagar"}
                                </Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </>
    );
}

export default Cart;
